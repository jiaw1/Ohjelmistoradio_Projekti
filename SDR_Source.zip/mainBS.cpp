/*
  simple tx rx test 
 - pregenerates samples
 - repeats same transmission
 - records samples 
 */

/** C++

compilation:

g++ -std=c++17 mainBS.cpp -lfftw3f -lfftw3 -luhd -lboost_system -lboost_program_options -pthread -ottx

*/

/**************************************************************
	Headers
**************************************************************/
//#include "mainHeaders.hpp"
#include "Headers.hpp"

#include "./PHY_BS.hpp"


/**************************************************************
	Functions
**************************************************************/
using namespace std;

static std::atomic<bool> STOP_SIGNAL_CALLED;

void os_signal_handler(int s){
  printf("\n Caught signal %d\n",s);
  STOP_SIGNAL_CALLED.store(true);
}

/**************************************************************
	Main
**************************************************************/
int UHD_SAFE_MAIN(int argc, char *argv[]) 
{
  int retVal = EXIT_SUCCESS;

  std::signal(SIGINT, os_signal_handler);

  // Queues for communicating between threads
  InterThreadQueueSDR7320<TXitem> txQueue;    // TX queue from the main to PHY thread
  InterThreadQueueSDR7320<RXitem> rxQueue;    // RX quewe from the PHY thread to main

  PHY_BS phyBS;                 // Create BS instance 
  phyBS.makeBSthread(txQueue,rxQueue);        // Start BS thread

  // random data generator
  int scaleSpectrum = 4;
  int NRBDL = 6*scaleSpectrum;
  int fft_size = 128*scaleSpectrum;
  RANDOM_DATA_FOR_PERFORMANCE_EST* testData = new RANDOM_DATA_FOR_PERFORMANCE_EST(fft_size,NRBDL);
  int nr_symbols = 6;
  int phy_packet_size = NRBDL*12/2 * nr_symbols;
 

  std::cout<<"BS main loops"<<std::endl;
  int waitForTx=0;
  while(true){
    if(STOP_SIGNAL_CALLED.load()) break;      // catch ctrl-C and end the code cleanly

    std::this_thread::sleep_for(std::chrono::milliseconds(10));

    //********************************************************************
    // tx 
    //********************************************************************

    // in demo purposes we generate a packet for every 10th time instance 
    waitForTx++;
    if(!(waitForTx%10))
    {
      /* 
        Example data packet 
        Packet size - 144 bits  (int 0 or 1)            those are BPSK encoded in PHY   
        
        The example bits are binary bits of numbers from 0 - 99.  
      */
/*
      {
      std::vector<int> txData;  
      for(int i1 =0;i1 <phy_packet_size;i1++)
        txData.push_back((int)testData->m_data[i1]);
      
      
        
      auto txItem = std::unique_ptr<TXitem>(new TXitem());       // creates a send item that will hold the tx data
      txItem->insertData(std::move(txData));                     // put data into send item
      txItem->tx_meta_data.num_tx_symbols = 6;
      txQueue.writeItem(std::move(txItem));                      // send the bits vector            
      }
*/  
    }





    //********************************************************************
    // rx 
    //********************************************************************    
    auto rxItem = std::move(rxQueue.readItem()); // reads the received data from PHY
		if(rxItem != nullptr)                        // received a data packet
			{
      //    std::cout<<"received package"<<std::endl;    

      //
      // here would be received data processing 
      //
			
      std::this_thread::sleep_for(std::chrono::milliseconds(1) ); // placeholder for processing
      }
    rxItem.reset();

  }

  // send stop to the phy thread
  phyBS.stopProcessing();
  
  
  delete testData;
  
  std::this_thread::sleep_for(std::chrono::milliseconds(100));
 
  std::cout<<"Exit the main function"<<std::endl;

  return retVal;
}
