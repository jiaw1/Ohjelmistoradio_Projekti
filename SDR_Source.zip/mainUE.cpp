/*
  simple tx rx test 
 - pregenerates samples
 - repeats same transmission
 - records samples 
 */

/** C++

compilation:

g++ -std=c++17 mainUE.cpp -lfftw3f -lfftw3 -luhd -lboost_system -lboost_program_options -pthread -orrx

*/


/**************************************************************
	Headers
**************************************************************/

#include "Headers.hpp"
// #include "mainHeaders.hpp"

#include "./PHY_UE.hpp"
// #include "../PHY/PHY_UE.hpp"


using namespace std;

static std::atomic<bool> STOP_SIGNAL_CALLED;

void os_signal_handler(int s){
  printf("\n Caught signal %d\n",s);

  STOP_SIGNAL_CALLED.store(true);
}


int UHD_SAFE_MAIN(int argc, char *argv[]) 
{
  int retVal = EXIT_SUCCESS;

  std::signal(SIGINT, os_signal_handler);

  InterThreadQueueSDR7320<TXitem> txQueue; 
  InterThreadQueueSDR7320<RXitem> rxQueue; 

  PHY_UE phyUE;
  phyUE.makeUEthread(txQueue,rxQueue);

  std::cout<<"UE main loops"<<std::endl;


  // random data generator
  int scaleSpectrum = RATE_SCALING;
  int NRBDL = 6*scaleSpectrum;
  int fft_size = 128*scaleSpectrum;
  RANDOM_DATA_FOR_PERFORMANCE_EST* testData = new RANDOM_DATA_FOR_PERFORMANCE_EST(fft_size,NRBDL);
  int nr_symbols = 6;
  int phy_packet_size = NRBDL*12/2 * nr_symbols;
 


  int waitForTx=0;
 // while stop condition becomes true
 while(true){
    if(STOP_SIGNAL_CALLED.load()) break;
 
    //***********************************************************************************
    // tx 
    //***********************************************************************************
    std::this_thread::sleep_for(std::chrono::milliseconds(10));

    // in demo purposes we generate a packet for every 10th time instance 
    waitForTx++;
    if(!(waitForTx%10))
    {
      /* 
        Example data packet 
        Packet size - phy_packet_len bits  (int 0 or 1)            those are BPSK encoded in PHY   
        
        The example bits are binary bits of numbers from 0 - 99.  
      */
      {
      //std::cout<<"send data"<<std::endl;
      /*std::vector<int> txData;
        for(int i1=0;i1<ceil(phy_packet_size/8);i1++)
        {
          uint8_t tmp =(uint8_t) i1;
          for(int i2=0;i2<8;i2++)
            txData.push_back((int) ((tmp>>i2) &1));
        }
      */

      std::vector<int> txData;  
      for(int i1 =0;i1 <phy_packet_size;i1++)
        txData.push_back((int)testData->m_data[i1]);


      auto txItem = std::unique_ptr<TXitem>(new TXitem());       // creates a send item that will hold the tx data
      txItem->insertData(std::move(txData));                     // put data into send item
      txQueue.writeItem(std::move(txItem));                      // send the bits vector
      }

    }

    //***********************************************************************************      
    // rx
    //***********************************************************************************
    {
    auto tmp = std::move(rxQueue.readItem()); // reads the received data from PHY
		if(tmp != nullptr)                        // received a data packet
			{
//      std::cout<<"probably received data"<<std::endl;
/*
      for(int i1=0;i1<phy_packet_size;i1++)
      {
        if((i1!=0) &(i1%8)==0)
          std::cout<<std::endl;
//          std::cout<<(int)(tmp->elem.at(i1)<0)<<" ";
          std::cout<<(int)(tmp->elem.at(i1))<<" ";
        }
      std::cout<<std::endl;
*/    
      tmp.reset();
      //
      // here would be received data processing 
      }
    } 

 }

  // send stop to the phy thread
  phyUE.stopProcessing();
 

  std::cout<<"Exit the main function"<<std::endl;

  return retVal;
}

